# system configuration generated and used by the sysconfig module
build_time_vars = {'ABIFLAGS': '',
 'AC_APPLE_UNIVERSAL_BUILD': 0,
 'AIX_BUILDDATE': 0,
 'AIX_GENUINE_CPLUSPLUS': 0,
 'ALIGNOF_LONG': 8,
 'ALIGNOF_SIZE_T': 8,
 'ALT_SOABI': 0,
 'ANDROID_API_LEVEL': 0,
 'AR': '/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/ar',
 'ARFLAGS': 'rcs',
 'BASECFLAGS': '-Wsign-compare -Wunreachable-code',
 'BASECPPFLAGS': '',
 'BASEMODLIBS': '',
 'BINDIR': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/bin',
 'BINLIBDEST': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib/python3.11',
 'BLDLIBRARY': 'libpython3.11.a',
 'BLDSHARED': 'ld -arch arm64 '
              '-L/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/lib/iphoneos '
              '-L/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk/usr/lib '
              '-miphoneos-version-min=9.0 -undefined dynamic_lookup',
 'BOOTSTRAP_HEADERS': '\\',
 'BUILDEXE': '.exe',
 'BUILDPYTHON': 'python.exe',
 'BUILD_GNU_TYPE': 'x86_64-apple-darwin',
 'BYTESTR_DEPS': '\\',
 'CC': '/var/folders/bf/3jxsnlls7hd0nyk4c2pz9vg80000gn/T/tmp66v8btzg',
 'CCSHARED': '',
 'CFLAGS': '-Wsign-compare -Wunreachable-code -DNDEBUG -g -fwrapv -O3 -Wall '
           '-O3 -miphoneos-version-min=9.0 '
           '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
           '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
           '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
           '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
           '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
           '-O3 -miphoneos-version-min=9.0 '
           '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
           '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
           '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
           '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
           '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk',
 'CFLAGSFORSHARED': '',
 'CFLAGS_ALIASING': '-fno-strict-aliasing',
 'CFLAGS_NODIST': '',
 'CONFIGFILES': 'configure configure.ac acconfig.h pyconfig.h.in '
                'Makefile.pre.in',
 'CONFIGURE_CFLAGS': '-O3 -miphoneos-version-min=9.0 '
                     '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                     '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                     '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                     '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                     '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk',
 'CONFIGURE_CFLAGS_NODIST': '-std=c11 -Wextra -Wno-unused-parameter '
                            '-Wno-missing-field-initializers '
                            '-Wstrict-prototypes '
                            '-Werror=implicit-function-declaration '
                            '-fvisibility=hidden',
 'CONFIGURE_CPPFLAGS': '',
 'CONFIGURE_LDFLAGS': '-arch arm64 '
                      '-L/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/lib/iphoneos '
                      '-L/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk/usr/lib '
                      '-miphoneos-version-min=9.0 -undefined dynamic_lookup',
 'CONFIGURE_LDFLAGS_NODIST': '',
 'CONFIGURE_LDFLAGS_NOLTO': '',
 'CONFIG_ARGS': "'CC=/var/folders/bf/3jxsnlls7hd0nyk4c2pz9vg80000gn/T/tmp66v8btzg' "
                "'LD=/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/ld' "
                "'CFLAGS=-O3 -miphoneos-version-min=9.0 "
                '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                "--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk' "
                "'LDFLAGS=-arch arm64 "
                '-L/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/lib/iphoneos '
                '-L/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk/usr/lib '
                "-miphoneos-version-min=9.0 -undefined dynamic_lookup' "
                "'ac_cv_file__dev_ptmx=yes' 'ac_cv_file__dev_ptc=no' "
                "'ac_cv_little_endian_double=yes' 'ac_cv_func_memrchr=no' "
                "'ac_cv_func_getentropy=no' 'ac_cv_func_getresuid=no' "
                "'ac_cv_func_getresgid=no' 'ac_cv_func_setresgid=no' "
                "'ac_cv_func_setresuid=no' 'ac_cv_func_plock=no' "
                "'ac_cv_func_dup3=no' 'ac_cv_func_pipe2=no' "
                "'ac_cv_func_preadv=no' 'ac_cv_func_pwritev=no' "
                "'ac_cv_func_preadv2=no' 'ac_cv_func_pwritev2=no' "
                "'ac_cv_func_mkfifoat=no' 'ac_cv_func_mknodat=no' "
                "'ac_cv_func_posix_fadvise=no' 'ac_cv_func_posix_fallocate=no' "
                "'ac_cv_func_sigwaitinfo=no' 'ac_cv_func_sigtimedwait=no' "
                "'ac_cv_func_clock_settime=no' "
                "'ac_cv_func_pthread_getcpuclockid=no' "
                "'ac_cv_func_sched_setscheduler=no' "
                "'ac_cv_func_sched_setparam=no' 'ac_cv_func_clock_gettime=no' "
                "'ac_cv_func_rtpSpawn=no' 'ac_cv_func_fdwalk=no' "
                "'ac_cv_func_futimesat=no' 'ac_cv_func_copy_file_range=no' "
                "'ac_cv_func_fexecve=no' 'ac_cv_func_execve=no' "
                "'ac_cv_func_sched_rr_get_interval=no' "
                "'ac_cv_func_explicit_bzero=no' "
                "'ac_cv_func_explicit_memset=no' 'ac_cv_func_close_range=no' "
                "'ac_cv_search_crypt_r=no' 'ac_cv_func_fork1=no' "
                "'ac_cv_func_system=no' 'ac_cv_func_clock_nanosleep=no' "
                "'ac_cv_func_splice=no' 'ac_cv_func_mremap=no' "
                "'--host=aarch64-apple-ios' '--build=x86_64-apple-darwin' "
                "'--with-build-python=/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/hostpython3/bin/python3' "
                "'--prefix=/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3' "
                "'--without-ensurepip' '--with-system-ffi' '--enable-ipv6' "
                "'PYTHON_FOR_BUILD=_PYTHON_PROJECT_BASE=/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6                     "
                '_PYTHON_HOST_PLATFORM=$(_PYTHON_HOST_PLATFORM)                     '
                'PYTHONPATH=$(shell test -f pybuilddir.txt && echo '
                '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6/`cat '
                'pybuilddir.txt`:)./Lib                    '
                '_PYTHON_SYSCONFIGDATA_NAME=_sysconfigdata__ios_darwin                    '
                "/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/hostpython3/bin/python' "
                "'build_alias=x86_64-apple-darwin' "
                "'host_alias=aarch64-apple-ios'",
 'CONFINCLUDEDIR': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include',
 'CONFINCLUDEPY': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11',
 'COREPYTHONPATH': '',
 'COVERAGE_INFO': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6/coverage.info',
 'COVERAGE_LCOV_OPTIONS': '--rc lcov_branch_coverage=1',
 'COVERAGE_REPORT': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6/lcov-report',
 'COVERAGE_REPORT_OPTIONS': '--rc lcov_branch_coverage=1 --branch-coverage '
                            '--title "CPython 3.11 LCOV report [commit $(shell '
                            ')]"',
 'CPPFLAGS': '-I. -I./Include',
 'CXX': '/var/folders/bf/3jxsnlls7hd0nyk4c2pz9vg80000gn/T/tmpxiha31s0',
 'DECIMAL_CFLAGS': '-I./Modules/_decimal/libmpdec -DCONFIG_64=1 -DANSI=1 '
                   '-DHAVE_UINT128_T=1',
 'DECIMAL_LDFLAGS': '-lm Modules/_decimal/libmpdec/libmpdec.a',
 'DEEPFREEZE_C': 'Python/deepfreeze/deepfreeze.c',
 'DEEPFREEZE_DEPS': './Tools/scripts/deepfreeze.py '
                    './Programs/_freeze_module.py \\',
 'DEEPFREEZE_OBJS': 'Python/deepfreeze/deepfreeze.o',
 'DESTDIRS': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3 '
             '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib '
             '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib/python3.11 '
             '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib/python3.11/lib-dynload',
 'DESTLIB': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib/python3.11',
 'DESTPATH': '',
 'DESTSHARED': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib/python3.11/lib-dynload',
 'DFLAGS': '',
 'DIRMODE': 755,
 'DIST': 'README.rst ChangeLog configure configure.ac acconfig.h pyconfig.h.in '
         'Makefile.pre.in Include Lib Misc Ext-dummy',
 'DISTDIRS': 'Include Lib Misc Ext-dummy',
 'DISTFILES': 'README.rst ChangeLog configure configure.ac acconfig.h '
              'pyconfig.h.in Makefile.pre.in',
 'DLINCLDIR': '.',
 'DLLLIBRARY': '',
 'DOUBLE_IS_ARM_MIXED_ENDIAN_IEEE754': 0,
 'DOUBLE_IS_BIG_ENDIAN_IEEE754': 0,
 'DOUBLE_IS_LITTLE_ENDIAN_IEEE754': 1,
 'DTRACE': '',
 'DTRACE_DEPS': '\\',
 'DTRACE_HEADERS': '',
 'DTRACE_OBJS': '',
 'DYNLOADFILE': 'dynload_shlib.o',
 'ENABLE_IPV6': 1,
 'ENSUREPIP': 'no',
 'EXE': '',
 'EXEMODE': 755,
 'EXPAT_CFLAGS': '-I./Modules/expat',
 'EXPAT_LDFLAGS': '-lm Modules/expat/libexpat.a',
 'EXPORTSFROM': '',
 'EXPORTSYMS': '',
 'EXTRATESTOPTS': '',
 'EXTRA_CFLAGS': '',
 'EXT_SUFFIX': '.cpython-311-darwin.so',
 'FILEMODE': 644,
 'FLOAT_WORDS_BIGENDIAN': 0,
 'FREEZE_MODULE': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/hostpython3/bin/python3 '
                  './Programs/_freeze_module.py',
 'FREEZE_MODULE_BOOTSTRAP': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/hostpython3/bin/python3 '
                            './Programs/_freeze_module.py',
 'FREEZE_MODULE_BOOTSTRAP_DEPS': './Programs/_freeze_module.py',
 'FREEZE_MODULE_DEPS': './Programs/_freeze_module.py',
 'FROZEN_FILES_IN': '\\',
 'FROZEN_FILES_OUT': '\\',
 'GETPGRP_HAVE_ARG': 0,
 'GITBRANCH': '',
 'GITTAG': '',
 'GITVERSION': '',
 'GNULD': 'no',
 'HAVE_ACCEPT': 1,
 'HAVE_ACCEPT4': 1,
 'HAVE_ACOSH': 1,
 'HAVE_ADDRINFO': 1,
 'HAVE_ALARM': 1,
 'HAVE_ALIGNED_REQUIRED': 1,
 'HAVE_ALLOCA_H': 1,
 'HAVE_ALTZONE': 0,
 'HAVE_ASINH': 1,
 'HAVE_ASM_TYPES_H': 0,
 'HAVE_ATANH': 1,
 'HAVE_BIND': 1,
 'HAVE_BIND_TEXTDOMAIN_CODESET': 1,
 'HAVE_BLUETOOTH_BLUETOOTH_H': 0,
 'HAVE_BLUETOOTH_H': 0,
 'HAVE_BROKEN_MBSTOWCS': 0,
 'HAVE_BROKEN_NICE': 0,
 'HAVE_BROKEN_PIPE_BUF': 0,
 'HAVE_BROKEN_POLL': 0,
 'HAVE_BROKEN_POSIX_SEMAPHORES': 0,
 'HAVE_BROKEN_PTHREAD_SIGMASK': 0,
 'HAVE_BROKEN_SEM_GETVALUE': 1,
 'HAVE_BROKEN_UNSETENV': 0,
 'HAVE_BUILTIN_ATOMIC': 1,
 'HAVE_BZLIB_H': 0,
 'HAVE_CHFLAGS': 1,
 'HAVE_CHMOD': 1,
 'HAVE_CHOWN': 1,
 'HAVE_CHROOT': 1,
 'HAVE_CLOCK': 1,
 'HAVE_CLOCK_GETRES': 1,
 'HAVE_CLOCK_GETTIME': 0,
 'HAVE_CLOCK_NANOSLEEP': 0,
 'HAVE_CLOCK_SETTIME': 0,
 'HAVE_CLOSE_RANGE': 0,
 'HAVE_COMPUTED_GOTOS': 0,
 'HAVE_CONFSTR': 1,
 'HAVE_CONIO_H': 0,
 'HAVE_CONNECT': 1,
 'HAVE_COPY_FILE_RANGE': 0,
 'HAVE_CRYPT_H': 0,
 'HAVE_CRYPT_R': 0,
 'HAVE_CTERMID': 1,
 'HAVE_CTERMID_R': 1,
 'HAVE_CURSES_FILTER': 0,
 'HAVE_CURSES_H': 0,
 'HAVE_CURSES_HAS_KEY': 0,
 'HAVE_CURSES_IMMEDOK': 0,
 'HAVE_CURSES_IS_PAD': 0,
 'HAVE_CURSES_IS_TERM_RESIZED': 0,
 'HAVE_CURSES_RESIZETERM': 0,
 'HAVE_CURSES_RESIZE_TERM': 0,
 'HAVE_CURSES_SYNCOK': 0,
 'HAVE_CURSES_TYPEAHEAD': 0,
 'HAVE_CURSES_USE_ENV': 0,
 'HAVE_CURSES_WCHGAT': 0,
 'HAVE_DB_H': 1,
 'HAVE_DECL_RTLD_DEEPBIND': 0,
 'HAVE_DECL_RTLD_GLOBAL': 1,
 'HAVE_DECL_RTLD_LAZY': 1,
 'HAVE_DECL_RTLD_LOCAL': 1,
 'HAVE_DECL_RTLD_MEMBER': 0,
 'HAVE_DECL_RTLD_NODELETE': 1,
 'HAVE_DECL_RTLD_NOLOAD': 1,
 'HAVE_DECL_RTLD_NOW': 1,
 'HAVE_DECL_TZNAME': 0,
 'HAVE_DEVICE_MACROS': 1,
 'HAVE_DEV_PTC': 0,
 'HAVE_DEV_PTMX': 1,
 'HAVE_DIRECT_H': 0,
 'HAVE_DIRENT_D_TYPE': 1,
 'HAVE_DIRENT_H': 1,
 'HAVE_DIRFD': 1,
 'HAVE_DLFCN_H': 1,
 'HAVE_DLOPEN': 1,
 'HAVE_DUP': 1,
 'HAVE_DUP2': 1,
 'HAVE_DUP3': 0,
 'HAVE_DYLD_SHARED_CACHE_CONTAINS_PATH': 1,
 'HAVE_DYNAMIC_LOADING': 1,
 'HAVE_ENDIAN_H': 1,
 'HAVE_EPOLL': 0,
 'HAVE_EPOLL_CREATE1': 0,
 'HAVE_ERF': 1,
 'HAVE_ERFC': 1,
 'HAVE_ERRNO_H': 1,
 'HAVE_EVENTFD': 0,
 'HAVE_EXECV': 1,
 'HAVE_EXPLICIT_BZERO': 0,
 'HAVE_EXPLICIT_MEMSET': 0,
 'HAVE_EXPM1': 1,
 'HAVE_FACCESSAT': 1,
 'HAVE_FCHDIR': 1,
 'HAVE_FCHMOD': 1,
 'HAVE_FCHMODAT': 1,
 'HAVE_FCHOWN': 1,
 'HAVE_FCHOWNAT': 1,
 'HAVE_FCNTL_H': 1,
 'HAVE_FDATASYNC': 0,
 'HAVE_FDOPENDIR': 1,
 'HAVE_FDWALK': 0,
 'HAVE_FEXECVE': 0,
 'HAVE_FLOCK': 1,
 'HAVE_FORK': 1,
 'HAVE_FORK1': 0,
 'HAVE_FORKPTY': 1,
 'HAVE_FPATHCONF': 1,
 'HAVE_FSEEK64': 1,
 'HAVE_FSEEKO': 1,
 'HAVE_FSTATAT': 1,
 'HAVE_FSTATVFS': 1,
 'HAVE_FSYNC': 1,
 'HAVE_FTELL64': 1,
 'HAVE_FTELLO': 1,
 'HAVE_FTIME': 1,
 'HAVE_FTRUNCATE': 1,
 'HAVE_FUTIMENS': 1,
 'HAVE_FUTIMES': 1,
 'HAVE_FUTIMESAT': 0,
 'HAVE_GAI_STRERROR': 1,
 'HAVE_GCC_ASM_FOR_MC68881': 0,
 'HAVE_GCC_ASM_FOR_X64': 0,
 'HAVE_GCC_ASM_FOR_X87': 0,
 'HAVE_GCC_UINT128_T': 1,
 'HAVE_GDBM_DASH_NDBM_H': 0,
 'HAVE_GDBM_H': 0,
 'HAVE_GDBM_NDBM_H': 0,
 'HAVE_GETADDRINFO': 1,
 'HAVE_GETC_UNLOCKED': 1,
 'HAVE_GETEGID': 1,
 'HAVE_GETENTROPY': 0,
 'HAVE_GETEUID': 1,
 'HAVE_GETGID': 1,
 'HAVE_GETGRGID': 1,
 'HAVE_GETGRGID_R': 1,
 'HAVE_GETGRNAM_R': 1,
 'HAVE_GETGROUPLIST': 1,
 'HAVE_GETGROUPS': 1,
 'HAVE_GETHOSTBYADDR': 1,
 'HAVE_GETHOSTBYNAME': 1,
 'HAVE_GETHOSTBYNAME_R': 1,
 'HAVE_GETHOSTBYNAME_R_3_ARG': 0,
 'HAVE_GETHOSTBYNAME_R_5_ARG': 0,
 'HAVE_GETHOSTBYNAME_R_6_ARG': 0,
 'HAVE_GETHOSTNAME': 1,
 'HAVE_GETITIMER': 1,
 'HAVE_GETLOADAVG': 1,
 'HAVE_GETLOGIN': 1,
 'HAVE_GETNAMEINFO': 1,
 'HAVE_GETPAGESIZE': 1,
 'HAVE_GETPEERNAME': 1,
 'HAVE_GETPGID': 1,
 'HAVE_GETPGRP': 1,
 'HAVE_GETPID': 1,
 'HAVE_GETPPID': 1,
 'HAVE_GETPRIORITY': 1,
 'HAVE_GETPROTOBYNAME': 1,
 'HAVE_GETPWENT': 1,
 'HAVE_GETPWNAM_R': 1,
 'HAVE_GETPWUID': 1,
 'HAVE_GETPWUID_R': 1,
 'HAVE_GETRANDOM': 0,
 'HAVE_GETRANDOM_SYSCALL': 0,
 'HAVE_GETRESGID': 0,
 'HAVE_GETRESUID': 0,
 'HAVE_GETRUSAGE': 1,
 'HAVE_GETSERVBYNAME': 1,
 'HAVE_GETSERVBYPORT': 1,
 'HAVE_GETSID': 1,
 'HAVE_GETSOCKNAME': 1,
 'HAVE_GETSPENT': 1,
 'HAVE_GETSPNAM': 1,
 'HAVE_GETUID': 1,
 'HAVE_GETWD': 1,
 'HAVE_GLIBC_MEMMOVE_BUG': 0,
 'HAVE_GRP_H': 1,
 'HAVE_HSTRERROR': 1,
 'HAVE_HTOLE64': 0,
 'HAVE_IEEEFP_H': 0,
 'HAVE_IF_NAMEINDEX': 1,
 'HAVE_INET_ATON': 1,
 'HAVE_INET_NTOA': 1,
 'HAVE_INET_PTON': 1,
 'HAVE_INITGROUPS': 1,
 'HAVE_INTTYPES_H': 1,
 'HAVE_IO_H': 0,
 'HAVE_IPA_PURE_CONST_BUG': 0,
 'HAVE_KILL': 1,
 'HAVE_KILLPG': 1,
 'HAVE_KQUEUE': 1,
 'HAVE_LANGINFO_H': 1,
 'HAVE_LARGEFILE_SUPPORT': 0,
 'HAVE_LCHFLAGS': 1,
 'HAVE_LCHMOD': 1,
 'HAVE_LCHOWN': 1,
 'HAVE_LIBB2': 0,
 'HAVE_LIBDB': 0,
 'HAVE_LIBDL': 1,
 'HAVE_LIBDLD': 0,
 'HAVE_LIBGDBM_COMPAT': 0,
 'HAVE_LIBIEEE': 0,
 'HAVE_LIBINTL_H': 0,
 'HAVE_LIBNDBM': 0,
 'HAVE_LIBREADLINE': 1,
 'HAVE_LIBRESOLV': 0,
 'HAVE_LIBSENDFILE': 0,
 'HAVE_LIBSQLITE3': 1,
 'HAVE_LIBUTIL_H': 0,
 'HAVE_LINK': 1,
 'HAVE_LINKAT': 1,
 'HAVE_LINUX_AUXVEC_H': 0,
 'HAVE_LINUX_CAN_BCM_H': 0,
 'HAVE_LINUX_CAN_H': 0,
 'HAVE_LINUX_CAN_J1939_H': 0,
 'HAVE_LINUX_CAN_RAW_FD_FRAMES': 0,
 'HAVE_LINUX_CAN_RAW_H': 0,
 'HAVE_LINUX_CAN_RAW_JOIN_FILTERS': 0,
 'HAVE_LINUX_LIMITS_H': 0,
 'HAVE_LINUX_MEMFD_H': 0,
 'HAVE_LINUX_NETLINK_H': 0,
 'HAVE_LINUX_QRTR_H': 0,
 'HAVE_LINUX_RANDOM_H': 0,
 'HAVE_LINUX_SOUNDCARD_H': 0,
 'HAVE_LINUX_TIPC_H': 0,
 'HAVE_LINUX_VM_SOCKETS_H': 0,
 'HAVE_LINUX_WAIT_H': 0,
 'HAVE_LISTEN': 1,
 'HAVE_LOCKF': 1,
 'HAVE_LOG1P': 1,
 'HAVE_LOG2': 1,
 'HAVE_LOGIN_TTY': 1,
 'HAVE_LONG_DOUBLE': 1,
 'HAVE_LSTAT': 1,
 'HAVE_LUTIMES': 1,
 'HAVE_LZMA_H': 0,
 'HAVE_MADVISE': 1,
 'HAVE_MAKEDEV': 1,
 'HAVE_MBRTOWC': 1,
 'HAVE_MEMFD_CREATE': 0,
 'HAVE_MEMORY_H': 1,
 'HAVE_MEMRCHR': 0,
 'HAVE_MKDIRAT': 1,
 'HAVE_MKFIFO': 1,
 'HAVE_MKFIFOAT': 0,
 'HAVE_MKNOD': 1,
 'HAVE_MKNODAT': 0,
 'HAVE_MKTIME': 1,
 'HAVE_MMAP': 1,
 'HAVE_MREMAP': 0,
 'HAVE_NANOSLEEP': 1,
 'HAVE_NCURSES_H': 0,
 'HAVE_NDBM_H': 1,
 'HAVE_NDIR_H': 0,
 'HAVE_NETCAN_CAN_H': 0,
 'HAVE_NETDB_H': 1,
 'HAVE_NETINET_IN_H': 1,
 'HAVE_NETPACKET_PACKET_H': 0,
 'HAVE_NET_IF_H': 1,
 'HAVE_NICE': 1,
 'HAVE_NON_UNICODE_WCHAR_T_REPRESENTATION': 0,
 'HAVE_OPENAT': 1,
 'HAVE_OPENDIR': 1,
 'HAVE_OPENPTY': 1,
 'HAVE_PATHCONF': 1,
 'HAVE_PAUSE': 1,
 'HAVE_PIPE': 1,
 'HAVE_PIPE2': 0,
 'HAVE_PLOCK': 0,
 'HAVE_POLL': 1,
 'HAVE_POLL_H': 1,
 'HAVE_POSIX_FADVISE': 0,
 'HAVE_POSIX_FALLOCATE': 0,
 'HAVE_POSIX_SPAWN': 1,
 'HAVE_POSIX_SPAWNP': 1,
 'HAVE_PREAD': 1,
 'HAVE_PREADV': 0,
 'HAVE_PREADV2': 0,
 'HAVE_PRLIMIT': 0,
 'HAVE_PROCESS_H': 0,
 'HAVE_PROTOTYPES': 1,
 'HAVE_PTHREAD_CONDATTR_SETCLOCK': 1,
 'HAVE_PTHREAD_DESTRUCTOR': 0,
 'HAVE_PTHREAD_GETCPUCLOCKID': 0,
 'HAVE_PTHREAD_H': 1,
 'HAVE_PTHREAD_INIT': 1,
 'HAVE_PTHREAD_KILL': 1,
 'HAVE_PTHREAD_SIGMASK': 1,
 'HAVE_PTHREAD_STUBS': 0,
 'HAVE_PTY_H': 0,
 'HAVE_PWRITE': 1,
 'HAVE_PWRITEV': 0,
 'HAVE_PWRITEV2': 0,
 'HAVE_READLINK': 1,
 'HAVE_READLINKAT': 1,
 'HAVE_READV': 1,
 'HAVE_REALPATH': 1,
 'HAVE_RECVFROM': 1,
 'HAVE_RENAMEAT': 1,
 'HAVE_RL_APPEND_HISTORY': 1,
 'HAVE_RL_CATCH_SIGNAL': 0,
 'HAVE_RL_COMPLETION_APPEND_CHARACTER': 0,
 'HAVE_RL_COMPLETION_DISPLAY_MATCHES_HOOK': 1,
 'HAVE_RL_COMPLETION_MATCHES': 1,
 'HAVE_RL_COMPLETION_SUPPRESS_APPEND': 0,
 'HAVE_RL_PRE_INPUT_HOOK': 1,
 'HAVE_RL_RESIZE_TERMINAL': 1,
 'HAVE_RPC_RPC_H': 1,
 'HAVE_RTPSPAWN': 0,
 'HAVE_SCHED_GET_PRIORITY_MAX': 1,
 'HAVE_SCHED_H': 1,
 'HAVE_SCHED_RR_GET_INTERVAL': 0,
 'HAVE_SCHED_SETAFFINITY': 1,
 'HAVE_SCHED_SETPARAM': 0,
 'HAVE_SCHED_SETSCHEDULER': 0,
 'HAVE_SEM_CLOCKWAIT': 1,
 'HAVE_SEM_GETVALUE': 1,
 'HAVE_SEM_OPEN': 1,
 'HAVE_SEM_TIMEDWAIT': 1,
 'HAVE_SEM_UNLINK': 1,
 'HAVE_SENDFILE': 1,
 'HAVE_SENDTO': 1,
 'HAVE_SETEGID': 1,
 'HAVE_SETEUID': 1,
 'HAVE_SETGID': 1,
 'HAVE_SETGROUPS': 1,
 'HAVE_SETHOSTNAME': 1,
 'HAVE_SETITIMER': 1,
 'HAVE_SETJMP_H': 1,
 'HAVE_SETLOCALE': 1,
 'HAVE_SETPGID': 1,
 'HAVE_SETPGRP': 1,
 'HAVE_SETPRIORITY': 1,
 'HAVE_SETREGID': 1,
 'HAVE_SETRESGID': 0,
 'HAVE_SETRESUID': 0,
 'HAVE_SETREUID': 1,
 'HAVE_SETSID': 1,
 'HAVE_SETSOCKOPT': 1,
 'HAVE_SETUID': 1,
 'HAVE_SETVBUF': 1,
 'HAVE_SHADOW_H': 0,
 'HAVE_SHM_OPEN': 1,
 'HAVE_SHM_UNLINK': 1,
 'HAVE_SHUTDOWN': 1,
 'HAVE_SIGACTION': 1,
 'HAVE_SIGALTSTACK': 1,
 'HAVE_SIGFILLSET': 1,
 'HAVE_SIGINFO_T_SI_BAND': 1,
 'HAVE_SIGINTERRUPT': 1,
 'HAVE_SIGNAL_H': 1,
 'HAVE_SIGPENDING': 1,
 'HAVE_SIGRELSE': 1,
 'HAVE_SIGTIMEDWAIT': 0,
 'HAVE_SIGWAIT': 1,
 'HAVE_SIGWAITINFO': 0,
 'HAVE_SNPRINTF': 1,
 'HAVE_SOCKADDR_ALG': 0,
 'HAVE_SOCKADDR_SA_LEN': 1,
 'HAVE_SOCKADDR_STORAGE': 1,
 'HAVE_SOCKET': 1,
 'HAVE_SOCKETPAIR': 1,
 'HAVE_SPAWN_H': 1,
 'HAVE_SPLICE': 0,
 'HAVE_SSIZE_T': 1,
 'HAVE_STATVFS': 1,
 'HAVE_STAT_TV_NSEC': 0,
 'HAVE_STAT_TV_NSEC2': 1,
 'HAVE_STDARG_PROTOTYPES': 1,
 'HAVE_STDINT_H': 1,
 'HAVE_STDLIB_H': 1,
 'HAVE_STD_ATOMIC': 1,
 'HAVE_STRFTIME': 1,
 'HAVE_STRINGS_H': 1,
 'HAVE_STRING_H': 1,
 'HAVE_STRLCPY': 1,
 'HAVE_STROPTS_H': 0,
 'HAVE_STRSIGNAL': 1,
 'HAVE_STRUCT_PASSWD_PW_GECOS': 1,
 'HAVE_STRUCT_PASSWD_PW_PASSWD': 1,
 'HAVE_STRUCT_STAT_ST_BIRTHTIME': 1,
 'HAVE_STRUCT_STAT_ST_BLKSIZE': 1,
 'HAVE_STRUCT_STAT_ST_BLOCKS': 1,
 'HAVE_STRUCT_STAT_ST_FLAGS': 1,
 'HAVE_STRUCT_STAT_ST_GEN': 1,
 'HAVE_STRUCT_STAT_ST_RDEV': 1,
 'HAVE_STRUCT_TM_TM_ZONE': 1,
 'HAVE_SYMLINK': 1,
 'HAVE_SYMLINKAT': 1,
 'HAVE_SYNC': 1,
 'HAVE_SYSCONF': 1,
 'HAVE_SYSEXITS_H': 1,
 'HAVE_SYSLOG_H': 1,
 'HAVE_SYSTEM': 0,
 'HAVE_SYS_AUDIOIO_H': 0,
 'HAVE_SYS_AUXV_H': 0,
 'HAVE_SYS_BSDTTY_H': 0,
 'HAVE_SYS_DEVPOLL_H': 0,
 'HAVE_SYS_DIR_H': 0,
 'HAVE_SYS_ENDIAN_H': 1,
 'HAVE_SYS_EPOLL_H': 0,
 'HAVE_SYS_EVENTFD_H': 0,
 'HAVE_SYS_EVENT_H': 1,
 'HAVE_SYS_FILE_H': 1,
 'HAVE_SYS_IOCTL_H': 1,
 'HAVE_SYS_KERN_CONTROL_H': 0,
 'HAVE_SYS_LOADAVG_H': 0,
 'HAVE_SYS_LOCK_H': 1,
 'HAVE_SYS_MEMFD_H': 0,
 'HAVE_SYS_MKDEV_H': 0,
 'HAVE_SYS_MMAN_H': 1,
 'HAVE_SYS_MODEM_H': 0,
 'HAVE_SYS_NDIR_H': 0,
 'HAVE_SYS_PARAM_H': 1,
 'HAVE_SYS_POLL_H': 1,
 'HAVE_SYS_RANDOM_H': 0,
 'HAVE_SYS_RESOURCE_H': 1,
 'HAVE_SYS_SELECT_H': 1,
 'HAVE_SYS_SENDFILE_H': 0,
 'HAVE_SYS_SOCKET_H': 1,
 'HAVE_SYS_SOUNDCARD_H': 0,
 'HAVE_SYS_STATVFS_H': 1,
 'HAVE_SYS_STAT_H': 1,
 'HAVE_SYS_SYSCALL_H': 1,
 'HAVE_SYS_SYSMACROS_H': 0,
 'HAVE_SYS_SYS_DOMAIN_H': 0,
 'HAVE_SYS_TERMIO_H': 0,
 'HAVE_SYS_TIMES_H': 1,
 'HAVE_SYS_TIME_H': 1,
 'HAVE_SYS_TYPES_H': 1,
 'HAVE_SYS_UIO_H': 1,
 'HAVE_SYS_UN_H': 1,
 'HAVE_SYS_UTSNAME_H': 1,
 'HAVE_SYS_WAIT_H': 1,
 'HAVE_SYS_XATTR_H': 1,
 'HAVE_TCGETPGRP': 1,
 'HAVE_TCSETPGRP': 1,
 'HAVE_TEMPNAM': 1,
 'HAVE_TERMIOS_H': 1,
 'HAVE_TERM_H': 0,
 'HAVE_TIMEGM': 1,
 'HAVE_TIMES': 1,
 'HAVE_TMPFILE': 1,
 'HAVE_TMPNAM': 1,
 'HAVE_TMPNAM_R': 1,
 'HAVE_TM_ZONE': 1,
 'HAVE_TRUNCATE': 1,
 'HAVE_TTYNAME': 1,
 'HAVE_TZNAME': 0,
 'HAVE_UMASK': 1,
 'HAVE_UNAME': 1,
 'HAVE_UNISTD_H': 1,
 'HAVE_UNLINKAT': 1,
 'HAVE_USABLE_WCHAR_T': 0,
 'HAVE_UTIL_H': 1,
 'HAVE_UTIMENSAT': 1,
 'HAVE_UTIMES': 1,
 'HAVE_UTIME_H': 1,
 'HAVE_UTMP_H': 0,
 'HAVE_UUID_CREATE': 0,
 'HAVE_UUID_ENC_BE': 0,
 'HAVE_UUID_GENERATE_TIME_SAFE': 0,
 'HAVE_UUID_H': 0,
 'HAVE_UUID_UUID_H': 1,
 'HAVE_VFORK': 1,
 'HAVE_WAIT': 1,
 'HAVE_WAIT3': 1,
 'HAVE_WAIT4': 1,
 'HAVE_WAITID': 1,
 'HAVE_WAITPID': 1,
 'HAVE_WCHAR_H': 1,
 'HAVE_WCSCOLL': 1,
 'HAVE_WCSFTIME': 1,
 'HAVE_WCSXFRM': 1,
 'HAVE_WMEMCMP': 1,
 'HAVE_WORKING_TZSET': 0,
 'HAVE_WRITEV': 1,
 'HAVE_ZLIB_COPY': 1,
 'HAVE_ZLIB_H': 0,
 'HAVE__GETPTY': 1,
 'HOSTRUNNER': '',
 'HOST_GNU_TYPE': 'aarch64-apple-ios',
 'INCLDIRSTOMAKE': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include '
                   '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include '
                   '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                   '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11',
 'INCLUDEDIR': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include',
 'INCLUDEPY': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11',
 'INSTALL': '/opt/homebrew/bin/ginstall -c',
 'INSTALL_DATA': '/opt/homebrew/bin/ginstall -c -m 644',
 'INSTALL_PROGRAM': '/opt/homebrew/bin/ginstall -c',
 'INSTALL_SCRIPT': '/opt/homebrew/bin/ginstall -c',
 'INSTALL_SHARED': '/opt/homebrew/bin/ginstall -c -m 755',
 'INSTSONAME': 'libpython3.11.a',
 'IO_H': 'Modules/_io/_iomodule.h',
 'IO_OBJS': '\\',
 'LDCXXSHARED': 'ld',
 'LDFLAGS': '-arch arm64 '
            '-L/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/lib/iphoneos '
            '-L/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk/usr/lib '
            '-miphoneos-version-min=9.0 -undefined dynamic_lookup',
 'LDFLAGS_NODIST': '',
 'LDLIBRARY': 'libpython3.11.a',
 'LDLIBRARYDIR': '',
 'LDSHARED': 'ld -arch arm64 '
             '-L/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/lib/iphoneos '
             '-L/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk/usr/lib '
             '-miphoneos-version-min=9.0 -undefined dynamic_lookup',
 'LDVERSION': '3.11',
 'LIBC': '',
 'LIBDEST': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib/python3.11',
 'LIBDIR': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib',
 'LIBEXPAT_A': 'Modules/expat/libexpat.a',
 'LIBEXPAT_CFLAGS': '-I./Modules/expat -Wsign-compare -Wunreachable-code '
                    '-DNDEBUG -g -fwrapv -O3 -Wall -O3 '
                    '-miphoneos-version-min=9.0 '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                    '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
                    '-O3 -miphoneos-version-min=9.0 '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                    '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
                    '-std=c11 -Wextra -Wno-unused-parameter '
                    '-Wno-missing-field-initializers -Wstrict-prototypes '
                    '-Werror=implicit-function-declaration '
                    '-fvisibility=hidden  -I./Include/internal -I. -I./Include',
 'LIBEXPAT_HEADERS': '\\',
 'LIBEXPAT_OBJS': '\\',
 'LIBFFI_INCLUDEDIR': '/Library/Developer/CommandLineTools/SDKs/MacOSX26.sdk/usr/include/ffi',
 'LIBM': '-lm',
 'LIBMPDEC_A': 'Modules/_decimal/libmpdec/libmpdec.a',
 'LIBMPDEC_CFLAGS': '-I./Modules/_decimal/libmpdec -DCONFIG_64=1 -DANSI=1 '
                    '-DHAVE_UINT128_T=1 -Wsign-compare -Wunreachable-code '
                    '-DNDEBUG -g -fwrapv -O3 -Wall -O3 '
                    '-miphoneos-version-min=9.0 '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                    '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
                    '-O3 -miphoneos-version-min=9.0 '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                    '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                    '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
                    '-std=c11 -Wextra -Wno-unused-parameter '
                    '-Wno-missing-field-initializers -Wstrict-prototypes '
                    '-Werror=implicit-function-declaration '
                    '-fvisibility=hidden  -I./Include/internal -I. -I./Include',
 'LIBMPDEC_HEADERS': '\\',
 'LIBMPDEC_OBJS': '\\',
 'LIBOBJDIR': 'Python/',
 'LIBOBJS': '',
 'LIBPC': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib/pkgconfig',
 'LIBPL': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib/python3.11/config-3.11-darwin',
 'LIBPYTHON': '',
 'LIBRARY': 'libpython3.11.a',
 'LIBRARY_DEPS': 'libpython3.11.a',
 'LIBRARY_OBJS': '\\',
 'LIBRARY_OBJS_OMIT_FROZEN': '\\',
 'LIBS': '-ldl  -lpthread',
 'LIBSUBDIRS': 'asyncio \\',
 'LINKCC': '/var/folders/bf/3jxsnlls7hd0nyk4c2pz9vg80000gn/T/tmp66v8btzg',
 'LINKFORSHARED': '',
 'LINK_PYTHON_DEPS': 'libpython3.11.a',
 'LINK_PYTHON_OBJS': '\\',
 'LIPO_32BIT_FLAGS': '',
 'LIPO_INTEL64_FLAGS': '',
 'LLVM_PROF_ERR': 'no',
 'LLVM_PROF_FILE': '',
 'LLVM_PROF_MERGER': '',
 'LN': 'ln',
 'LOCALMODLIBS': '-L./../Support/BZip2 -lbz2          -lm    '
                 '-lssl                -lssl   -lm -lz   -lm -lm         -lz '
                 '-lm',
 'MACHDEP': 'ios',
 'MACHDEP_OBJS': '',
 'MACHDESTLIB': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib/python3.11',
 'MACOSX_DEPLOYMENT_TARGET': '',
 'MAINCC': '/var/folders/bf/3jxsnlls7hd0nyk4c2pz9vg80000gn/T/tmp66v8btzg',
 'MAJOR_IN_MKDEV': 0,
 'MAJOR_IN_SYSMACROS': 0,
 'MAKESETUP': './Modules/makesetup',
 'MANDIR': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/share/man',
 'MKDIR_P': '/opt/homebrew/bin/gmkdir -p',
 'MODBUILT_NAMES': '_asyncio  _bisect  _blake2  _sqlite3  _bz2  _codecs_cn  '
                   '_codecs_hk  _codecs_iso2022  _codecs_jp  _codecs_kr  '
                   '_codecs_tw  _contextvars  _crypt  _csv  _datetime  '
                   '_elementtree   _hashlib  _heapq  _json  _lsprof  _md5  '
                   '_multibytecodec  _opcode  _queue  _pickle  _random  _sha1  '
                   '_sha3  _sha256  _sha512  _socket  _ssl  _struct  array  '
                   'audioop  binascii  fcntl  grp  cmath  math  mmap  pyexpat  '
                   'resource  select  syslog  termios  unicodedata  zlib  '
                   '_ctypes_test  _testbuffer  _testinternalcapi  '
                   '_testimportmultiple  _ctypes  atexit  faulthandler  posix  '
                   '_signal  _tracemalloc  _codecs  _collections  errno  _io  '
                   'itertools  _sre  _thread  time  _weakref  _abc  '
                   '_functools  _locale  _operator  _stat  _symtable  pwd  '
                   'xxsubtype',
 'MODDISABLED_NAMES': '',
 'MODLIBS': '-L./../Support/BZip2 -lbz2          -lm    -lssl                '
            '-lssl   -lm -lz   -lm -lm         -lz -lm',
 'MODOBJS': 'Modules/_asynciomodule.o  Modules/_bisectmodule.o  '
            'Modules/_blake2/blake2module.o Modules/_blake2/blake2b_impl.o '
            'Modules/_blake2/blake2s_impl.o  Modules/_sqlite/blob.o '
            'Modules/_sqlite/connection.o Modules/_sqlite/cursor.o '
            'Modules/_sqlite/microprotocols.o Modules/_sqlite/module.o '
            'Modules/_sqlite/prepare_protocol.o Modules/_sqlite/row.o '
            'Modules/_sqlite/statement.o Modules/_sqlite/util.o  '
            'Modules/_bz2module.o  Modules/cjkcodecs/_codecs_cn.o  '
            'Modules/cjkcodecs/_codecs_hk.o  '
            'Modules/cjkcodecs/_codecs_iso2022.o  '
            'Modules/cjkcodecs/_codecs_jp.o  Modules/cjkcodecs/_codecs_kr.o  '
            'Modules/cjkcodecs/_codecs_tw.o  Modules/_contextvarsmodule.o  '
            'Modules/_cryptmodule.o  Modules/_csv.o  '
            'Modules/_datetimemodule.o  Modules/_elementtree.o   '
            'Modules/_hashopenssl.o  Modules/_heapqmodule.o  Modules/_json.o  '
            'Modules/_lsprof.o Modules/rotatingtree.o  Modules/md5module.o  '
            'Modules/cjkcodecs/multibytecodec.o  Modules/_opcode.o  '
            'Modules/_queuemodule.o  Modules/_pickle.o  '
            'Modules/_randommodule.o  Modules/sha1module.o  '
            'Modules/_sha3/sha3module.o  Modules/sha256module.o  '
            'Modules/sha512module.o  Modules/socketmodule.o  Modules/_ssl.o  '
            'Modules/_struct.o  Modules/arraymodule.o  Modules/audioop.o  '
            'Modules/binascii.o  Modules/fcntlmodule.o  Modules/grpmodule.o  '
            'Modules/cmathmodule.o  Modules/mathmodule.o  '
            'Modules/mmapmodule.o  Modules/expat/xmlparse.o '
            'Modules/expat/xmlrole.o Modules/expat/xmltok.o Modules/pyexpat.o  '
            'Modules/resource.o  Modules/selectmodule.o  '
            'Modules/syslogmodule.o  Modules/termios.o  Modules/unicodedata.o  '
            'Modules/zlibmodule.o  Modules/_ctypes/_ctypes_test.o  '
            'Modules/_testbuffer.o  Modules/_testinternalcapi.o  '
            'Modules/_testimportmultiple.o  Modules/_ctypes/_ctypes.o '
            'Modules/_ctypes/callbacks.o Modules/_ctypes/callproc.o '
            'Modules/_ctypes/stgdict.o Modules/_ctypes/cfield.o  '
            'Modules/atexitmodule.o  Modules/faulthandler.o  '
            'Modules/posixmodule.o  Modules/signalmodule.o  '
            'Modules/_tracemalloc.o  Modules/_codecsmodule.o  '
            'Modules/_collectionsmodule.o  Modules/errnomodule.o  '
            'Modules/_io/_iomodule.o Modules/_io/iobase.o Modules/_io/fileio.o '
            'Modules/_io/bytesio.o Modules/_io/bufferedio.o '
            'Modules/_io/textio.o Modules/_io/stringio.o  '
            'Modules/itertoolsmodule.o  Modules/_sre/sre.o  '
            'Modules/_threadmodule.o  Modules/timemodule.o  '
            'Modules/_weakref.o  Modules/_abc.o  Modules/_functoolsmodule.o  '
            'Modules/_localemodule.o  Modules/_operator.o  Modules/_stat.o  '
            'Modules/symtablemodule.o  Modules/pwdmodule.o  '
            'Modules/xxsubtype.o',
 'MODSHARED_NAMES': '',
 'MODULE_ARRAY_LDFLAGS': '',
 'MODULE_ARRAY_STATE': 'yes',
 'MODULE_ATEXIT_LDFLAGS': '',
 'MODULE_AUDIOOP_LDFLAGS': '-lm',
 'MODULE_AUDIOOP_STATE': 'yes',
 'MODULE_BINASCII_CFLAGS': '-DUSE_ZLIB_CRC32',
 'MODULE_BINASCII_LDFLAGS': '-lz',
 'MODULE_BINASCII_STATE': 'yes',
 'MODULE_CMATH_DEPS': './Modules/_math.h',
 'MODULE_CMATH_LDFLAGS': '-lm',
 'MODULE_CMATH_STATE': 'yes',
 'MODULE_ERRNO_LDFLAGS': '',
 'MODULE_FAULTHANDLER_LDFLAGS': '',
 'MODULE_FCNTL_LDFLAGS': '',
 'MODULE_FCNTL_STATE': 'yes',
 'MODULE_GRP_LDFLAGS': '',
 'MODULE_GRP_STATE': 'yes',
 'MODULE_ITERTOOLS_LDFLAGS': '',
 'MODULE_MATH_DEPS': './Modules/_math.h',
 'MODULE_MATH_LDFLAGS': '-lm',
 'MODULE_MATH_STATE': 'yes',
 'MODULE_MMAP_LDFLAGS': '',
 'MODULE_MMAP_STATE': 'yes',
 'MODULE_NIS_CFLAGS': '',
 'MODULE_NIS_LDFLAGS': '',
 'MODULE_NIS_STATE': 'yes',
 'MODULE_OBJS': '\\',
 'MODULE_OSSAUDIODEV_STATE': 'missing',
 'MODULE_POSIX_LDFLAGS': '',
 'MODULE_PWD_LDFLAGS': '',
 'MODULE_PWD_STATE': 'yes',
 'MODULE_PYEXPAT_CFLAGS': '-I./Modules/expat',
 'MODULE_PYEXPAT_DEPS': '\\ Modules/expat/libexpat.a',
 'MODULE_PYEXPAT_LDFLAGS': '-lm Modules/expat/libexpat.a',
 'MODULE_PYEXPAT_STATE': 'yes',
 'MODULE_RESOURCE_LDFLAGS': '',
 'MODULE_RESOURCE_STATE': 'yes',
 'MODULE_SELECT_LDFLAGS': '',
 'MODULE_SELECT_STATE': 'yes',
 'MODULE_SPWD_STATE': 'yes',
 'MODULE_SYSLOG_LDFLAGS': '',
 'MODULE_SYSLOG_STATE': 'yes',
 'MODULE_TERMIOS_LDFLAGS': '',
 'MODULE_TERMIOS_STATE': 'yes',
 'MODULE_TIME_LDFLAGS': '',
 'MODULE_TIME_STATE': 'yes',
 'MODULE_UNICODEDATA_DEPS': './Modules/unicodedata_db.h '
                            './Modules/unicodename_db.h',
 'MODULE_UNICODEDATA_LDFLAGS': '',
 'MODULE_UNICODEDATA_STATE': 'yes',
 'MODULE_XXLIMITED_35_STATE': 'yes',
 'MODULE_XXLIMITED_STATE': 'yes',
 'MODULE_XXSUBTYPE_LDFLAGS': '',
 'MODULE_ZLIB_CFLAGS': '',
 'MODULE_ZLIB_LDFLAGS': '-lz',
 'MODULE_ZLIB_STATE': 'yes',
 'MODULE__ABC_LDFLAGS': '',
 'MODULE__ASYNCIO_LDFLAGS': '',
 'MODULE__ASYNCIO_STATE': 'yes',
 'MODULE__BISECT_LDFLAGS': '',
 'MODULE__BISECT_STATE': 'yes',
 'MODULE__BLAKE2_CFLAGS': '',
 'MODULE__BLAKE2_DEPS': './Modules/_blake2/impl/blake2-config.h '
                        './Modules/_blake2/impl/blake2-impl.h '
                        './Modules/_blake2/impl/blake2.h '
                        './Modules/_blake2/impl/blake2b-load-sse2.h '
                        './Modules/_blake2/impl/blake2b-load-sse41.h '
                        './Modules/_blake2/impl/blake2b-ref.c '
                        './Modules/_blake2/impl/blake2b-round.h '
                        './Modules/_blake2/impl/blake2b.c '
                        './Modules/_blake2/impl/blake2s-load-sse2.h '
                        './Modules/_blake2/impl/blake2s-load-sse41.h '
                        './Modules/_blake2/impl/blake2s-load-xop.h '
                        './Modules/_blake2/impl/blake2s-ref.c '
                        './Modules/_blake2/impl/blake2s-round.h '
                        './Modules/_blake2/impl/blake2s.c '
                        './Modules/_blake2/blake2module.h ./Modules/hashlib.h',
 'MODULE__BLAKE2_LDFLAGS': '',
 'MODULE__BLAKE2_STATE': 'yes',
 'MODULE__BZ2_CFLAGS': '',
 'MODULE__BZ2_LDFLAGS': '-lbz2',
 'MODULE__BZ2_STATE': 'yes',
 'MODULE__CODECS_CN_LDFLAGS': '',
 'MODULE__CODECS_CN_STATE': 'yes',
 'MODULE__CODECS_HK_LDFLAGS': '',
 'MODULE__CODECS_HK_STATE': 'yes',
 'MODULE__CODECS_ISO2022_LDFLAGS': '',
 'MODULE__CODECS_ISO2022_STATE': 'yes',
 'MODULE__CODECS_JP_LDFLAGS': '',
 'MODULE__CODECS_JP_STATE': 'yes',
 'MODULE__CODECS_KR_LDFLAGS': '',
 'MODULE__CODECS_KR_STATE': 'yes',
 'MODULE__CODECS_LDFLAGS': '',
 'MODULE__CODECS_TW_LDFLAGS': '',
 'MODULE__CODECS_TW_STATE': 'yes',
 'MODULE__COLLECTIONS_LDFLAGS': '',
 'MODULE__CONTEXTVARS_LDFLAGS': '',
 'MODULE__CONTEXTVARS_STATE': 'yes',
 'MODULE__CRYPT_CFLAGS': '',
 'MODULE__CRYPT_LDFLAGS': '',
 'MODULE__CRYPT_STATE': 'yes',
 'MODULE__CSV_LDFLAGS': '',
 'MODULE__CSV_STATE': 'yes',
 'MODULE__CTYPES_DEPS': './Modules/_ctypes/ctypes.h',
 'MODULE__CTYPES_TEST_LDFLAGS': '-lm',
 'MODULE__CTYPES_TEST_STATE': 'yes',
 'MODULE__DATETIME_LDFLAGS': '-lm',
 'MODULE__DATETIME_STATE': 'yes',
 'MODULE__DECIMAL_CFLAGS': '-I./Modules/_decimal/libmpdec -DCONFIG_64=1 '
                           '-DANSI=1 -DHAVE_UINT128_T=1',
 'MODULE__DECIMAL_DEPS': './Modules/_decimal/docstrings.h \\ '
                         'Modules/_decimal/libmpdec/libmpdec.a',
 'MODULE__DECIMAL_LDFLAGS': '-lm Modules/_decimal/libmpdec/libmpdec.a',
 'MODULE__DECIMAL_STATE': 'yes',
 'MODULE__ELEMENTTREE_CFLAGS': '-I./Modules/expat',
 'MODULE__ELEMENTTREE_DEPS': './Modules/pyexpat.c \\ Modules/expat/libexpat.a',
 'MODULE__ELEMENTTREE_STATE': 'yes',
 'MODULE__FUNCTOOLS_LDFLAGS': '',
 'MODULE__GDBM_STATE': 'missing',
 'MODULE__HASHLIB_CFLAGS': '-I/opt/homebrew/Cellar/openssl@3/3.6.3/include',
 'MODULE__HASHLIB_DEPS': './Modules/hashlib.h',
 'MODULE__HASHLIB_LDFLAGS': '-L/opt/homebrew/Cellar/openssl@3/3.6.3/lib   '
                            '-lcrypto',
 'MODULE__HASHLIB_STATE': 'yes',
 'MODULE__HEAPQ_LDFLAGS': '',
 'MODULE__HEAPQ_STATE': 'yes',
 'MODULE__IO_CFLAGS': '-I./Modules/_io',
 'MODULE__IO_DEPS': './Modules/_io/_iomodule.h',
 'MODULE__IO_LDFLAGS': '',
 'MODULE__IO_STATE': 'yes',
 'MODULE__JSON_LDFLAGS': '',
 'MODULE__JSON_STATE': 'yes',
 'MODULE__LOCALE_LDFLAGS': '',
 'MODULE__LSPROF_LDFLAGS': '',
 'MODULE__LSPROF_STATE': 'yes',
 'MODULE__LZMA_CFLAGS': '-I/opt/homebrew/Cellar/xz/5.8.3/include',
 'MODULE__LZMA_LDFLAGS': '-L/opt/homebrew/Cellar/xz/5.8.3/lib -llzma',
 'MODULE__LZMA_STATE': 'yes',
 'MODULE__MD5_DEPS': './Modules/hashlib.h',
 'MODULE__MD5_LDFLAGS': '',
 'MODULE__MD5_STATE': 'yes',
 'MODULE__MULTIBYTECODEC_LDFLAGS': '',
 'MODULE__MULTIBYTECODEC_STATE': 'yes',
 'MODULE__MULTIPROCESSING_CFLAGS': '-I./Modules/_multiprocessing',
 'MODULE__MULTIPROCESSING_STATE': 'yes',
 'MODULE__OPCODE_LDFLAGS': '',
 'MODULE__OPCODE_STATE': 'yes',
 'MODULE__OPERATOR_LDFLAGS': '',
 'MODULE__PICKLE_LDFLAGS': '',
 'MODULE__PICKLE_STATE': 'yes',
 'MODULE__POSIXSHMEM_CFLAGS': '-I./Modules/_multiprocessing',
 'MODULE__POSIXSHMEM_LDFLAGS': '',
 'MODULE__POSIXSHMEM_STATE': 'yes',
 'MODULE__POSIXSUBPROCESS_STATE': 'yes',
 'MODULE__QUEUE_LDFLAGS': '',
 'MODULE__QUEUE_STATE': 'yes',
 'MODULE__RANDOM_LDFLAGS': '',
 'MODULE__RANDOM_STATE': 'yes',
 'MODULE__SCPROXY_STATE': 'n/a',
 'MODULE__SHA1_DEPS': './Modules/hashlib.h',
 'MODULE__SHA1_LDFLAGS': '',
 'MODULE__SHA1_STATE': 'yes',
 'MODULE__SHA256_DEPS': './Modules/hashlib.h',
 'MODULE__SHA256_LDFLAGS': '',
 'MODULE__SHA256_STATE': 'yes',
 'MODULE__SHA3_DEPS': './Modules/_sha3/sha3.c ./Modules/_sha3/sha3.h '
                      './Modules/hashlib.h',
 'MODULE__SHA3_LDFLAGS': '',
 'MODULE__SHA3_STATE': 'yes',
 'MODULE__SHA512_DEPS': './Modules/hashlib.h',
 'MODULE__SHA512_LDFLAGS': '',
 'MODULE__SHA512_STATE': 'yes',
 'MODULE__SIGNAL_LDFLAGS': '',
 'MODULE__SOCKET_DEPS': './Modules/socketmodule.h ./Modules/addrinfo.h '
                        './Modules/getaddrinfo.c ./Modules/getnameinfo.c',
 'MODULE__SOCKET_LDFLAGS': '',
 'MODULE__SOCKET_STATE': 'yes',
 'MODULE__SQLITE3_CFLAGS': '-I./Modules/_sqlite',
 'MODULE__SQLITE3_DEPS': './Modules/_sqlite/connection.h '
                         './Modules/_sqlite/cursor.h '
                         './Modules/_sqlite/microprotocols.h '
                         './Modules/_sqlite/module.h '
                         './Modules/_sqlite/prepare_protocol.h '
                         './Modules/_sqlite/row.h ./Modules/_sqlite/util.h',
 'MODULE__SQLITE3_LDFLAGS': '-lsqlite3',
 'MODULE__SQLITE3_STATE': 'yes',
 'MODULE__SRE_LDFLAGS': '',
 'MODULE__SSL_CFLAGS': '-I/opt/homebrew/Cellar/openssl@3/3.6.3/include',
 'MODULE__SSL_DEPS': './Modules/_ssl.h ./Modules/_ssl/cert.c '
                     './Modules/_ssl/debughelpers.c ./Modules/_ssl/misc.c '
                     './Modules/_ssl_data.h ./Modules/_ssl_data_111.h '
                     './Modules/_ssl_data_300.h ./Modules/socketmodule.h',
 'MODULE__SSL_LDFLAGS': '-L/opt/homebrew/Cellar/openssl@3/3.6.3/lib  -lssl '
                        '-lcrypto',
 'MODULE__SSL_STATE': 'yes',
 'MODULE__STATISTICS_LDFLAGS': '-lm',
 'MODULE__STATISTICS_STATE': 'yes',
 'MODULE__STAT_LDFLAGS': '',
 'MODULE__STRUCT_LDFLAGS': '',
 'MODULE__STRUCT_STATE': 'yes',
 'MODULE__SYMTABLE_LDFLAGS': '',
 'MODULE__TESTBUFFER_LDFLAGS': '',
 'MODULE__TESTBUFFER_STATE': 'yes',
 'MODULE__TESTCAPI_DEPS': './Modules/testcapi_long.h',
 'MODULE__TESTCAPI_STATE': 'yes',
 'MODULE__TESTCLINIC_STATE': 'yes',
 'MODULE__TESTIMPORTMULTIPLE_LDFLAGS': '',
 'MODULE__TESTIMPORTMULTIPLE_STATE': 'yes',
 'MODULE__TESTINTERNALCAPI_LDFLAGS': '',
 'MODULE__TESTINTERNALCAPI_STATE': 'yes',
 'MODULE__TESTMULTIPHASE_STATE': 'yes',
 'MODULE__THREAD_LDFLAGS': '',
 'MODULE__TKINTER_STATE': 'missing',
 'MODULE__TRACEMALLOC_LDFLAGS': '',
 'MODULE__TYPING_STATE': 'yes',
 'MODULE__UUID_CFLAGS': '',
 'MODULE__UUID_LDFLAGS': '',
 'MODULE__UUID_STATE': 'yes',
 'MODULE__WEAKREF_LDFLAGS': '',
 'MODULE__XXSUBINTERPRETERS_STATE': 'yes',
 'MODULE__XXTESTFUZZ_STATE': 'yes',
 'MODULE__ZONEINFO_STATE': 'yes',
 'MULTIARCH': 'darwin',
 'MULTIARCH_CPPFLAGS': '-DMULTIARCH=\\"darwin\\"',
 'MVWDELCH_IS_EXPRESSION': 0,
 'NO_AS_NEEDED': '-Wl,--no-as-needed',
 'OBJECT_OBJS': '\\',
 'OPENSSL_INCLUDES': '-I/opt/homebrew/Cellar/openssl@3/3.6.3/include',
 'OPENSSL_LDFLAGS': '-L/opt/homebrew/Cellar/openssl@3/3.6.3/lib',
 'OPENSSL_LIBS': '-lssl -lcrypto',
 'OPENSSL_RPATH': '',
 'OPT': '-DNDEBUG -g -fwrapv -O3 -Wall',
 'OTHER_LIBTOOL_OPT': '',
 'PACKAGE_BUGREPORT': 0,
 'PACKAGE_NAME': 0,
 'PACKAGE_STRING': 0,
 'PACKAGE_TARNAME': 0,
 'PACKAGE_URL': 0,
 'PACKAGE_VERSION': 0,
 'PARSER_HEADERS': '\\',
 'PARSER_OBJS': '\\ \\ Parser/myreadline.o Parser/tokenizer.o',
 'PEGEN_HEADERS': '\\',
 'PEGEN_OBJS': '\\',
 'PGO_PROF_GEN_FLAG': '',
 'PGO_PROF_USE_FLAG': '',
 'PLATLIBDIR': 'lib',
 'POBJS': '\\',
 'POSIX_SEMAPHORES_NOT_ENABLED': 0,
 'PROFILE_TASK': '-m test --pgo --timeout=1200',
 'PTHREAD_KEY_T_IS_COMPATIBLE_WITH_INT': 0,
 'PTHREAD_SYSTEM_SCHED_SUPPORTED': 0,
 'PURIFY': '',
 'PY3LIBRARY': '',
 'PYLONG_BITS_IN_DIGIT': 0,
 'PYTHON': 'python',
 'PYTHONFRAMEWORK': '',
 'PYTHONFRAMEWORKDIR': 'no-framework',
 'PYTHONFRAMEWORKINSTALLDIR': '',
 'PYTHONFRAMEWORKPREFIX': '',
 'PYTHONPATH': '',
 'PYTHON_FOR_BUILD': '_PYTHON_PROJECT_BASE=/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6 '
                     '_PYTHON_HOST_PLATFORM=$(_PYTHON_HOST_PLATFORM) '
                     'PYTHONPATH=$(shell test -f pybuilddir.txt && echo '
                     '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6/`cat '
                     'pybuilddir.txt`:)./Lib '
                     '_PYTHON_SYSCONFIGDATA_NAME=_sysconfigdata__ios_darwin '
                     '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/hostpython3/bin/python3',
 'PYTHON_FOR_BUILD_DEPS': '',
 'PYTHON_FOR_FREEZE': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/hostpython3/bin/python3',
 'PYTHON_FOR_REGEN': '',
 'PYTHON_HEADERS': '\\',
 'PYTHON_OBJS': '\\',
 'PY_BUILTIN_HASHLIB_HASHES': '"md5,sha1,sha256,sha512,sha3,blake2"',
 'PY_BUILTIN_MODULE_CFLAGS': '-Wsign-compare -Wunreachable-code -DNDEBUG -g '
                             '-fwrapv -O3 -Wall -O3 -miphoneos-version-min=9.0 '
                             '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                             '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                             '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                             '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                             '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
                             '-O3 -miphoneos-version-min=9.0 '
                             '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                             '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                             '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                             '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                             '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
                             '-std=c11 -Wextra -Wno-unused-parameter '
                             '-Wno-missing-field-initializers '
                             '-Wstrict-prototypes '
                             '-Werror=implicit-function-declaration '
                             '-fvisibility=hidden  -I./Include/internal -I. '
                             '-I./Include -DPy_BUILD_CORE_BUILTIN',
 'PY_CFLAGS': '-Wsign-compare -Wunreachable-code -DNDEBUG -g -fwrapv -O3 -Wall '
              '-O3 -miphoneos-version-min=9.0 '
              '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
              '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
              '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
              '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
              '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
              '-O3 -miphoneos-version-min=9.0 '
              '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
              '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
              '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
              '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
              '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk',
 'PY_CFLAGS_NODIST': '-std=c11 -Wextra -Wno-unused-parameter '
                     '-Wno-missing-field-initializers -Wstrict-prototypes '
                     '-Werror=implicit-function-declaration '
                     '-fvisibility=hidden  -I./Include/internal',
 'PY_COERCE_C_LOCALE': 1,
 'PY_CORE_CFLAGS': '-Wsign-compare -Wunreachable-code -DNDEBUG -g -fwrapv -O3 '
                   '-Wall -O3 -miphoneos-version-min=9.0 '
                   '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                   '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                   '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                   '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                   '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
                   '-O3 -miphoneos-version-min=9.0 '
                   '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                   '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                   '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                   '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                   '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
                   '-std=c11 -Wextra -Wno-unused-parameter '
                   '-Wno-missing-field-initializers -Wstrict-prototypes '
                   '-Werror=implicit-function-declaration -fvisibility=hidden  '
                   '-I./Include/internal -I. -I./Include -DPy_BUILD_CORE',
 'PY_CORE_LDFLAGS': '-arch arm64 '
                    '-L/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/lib/iphoneos '
                    '-L/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk/usr/lib '
                    '-miphoneos-version-min=9.0 -undefined dynamic_lookup',
 'PY_CPPFLAGS': '-I. -I./Include',
 'PY_ENABLE_SHARED': 0,
 'PY_FORMAT_SIZE_T': '"z"',
 'PY_LDFLAGS': '-arch arm64 '
               '-L/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/lib/iphoneos '
               '-L/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk/usr/lib '
               '-miphoneos-version-min=9.0 -undefined dynamic_lookup',
 'PY_LDFLAGS_NODIST': '',
 'PY_LDFLAGS_NOLTO': '-arch arm64 '
                     '-L/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/lib/iphoneos '
                     '-L/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk/usr/lib '
                     '-miphoneos-version-min=9.0 -undefined dynamic_lookup',
 'PY_SQLITE_ENABLE_LOAD_EXTENSION': 0,
 'PY_SQLITE_HAVE_SERIALIZE': 1,
 'PY_SSL_DEFAULT_CIPHERS': 1,
 'PY_SSL_DEFAULT_CIPHER_STRING': 0,
 'PY_STDMODULE_CFLAGS': '-Wsign-compare -Wunreachable-code -DNDEBUG -g -fwrapv '
                        '-O3 -Wall -O3 -miphoneos-version-min=9.0 '
                        '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                        '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                        '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                        '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                        '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
                        '-O3 -miphoneos-version-min=9.0 '
                        '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/ffi '
                        '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64/openssl '
                        '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/include/iphoneos-arm64 '
                        '-I/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/include/python3.11 '
                        '--sysroot=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS26.5.sdk '
                        '-std=c11 -Wextra -Wno-unused-parameter '
                        '-Wno-missing-field-initializers -Wstrict-prototypes '
                        '-Werror=implicit-function-declaration '
                        '-fvisibility=hidden  -I./Include/internal -I. '
                        '-I./Include',
 'PY_SUPPORT_TIER': 0,
 'Py_DEBUG': 0,
 'Py_ENABLE_SHARED': 0,
 'Py_HASH_ALGORITHM': 0,
 'Py_STATS': 0,
 'Py_TRACE_REFS': 0,
 'QUICKTESTOPTS': '-x test_subprocess test_io test_lib2to3 \\',
 'READELF': ':',
 'RESSRCDIR': 'Mac/Resources/framework',
 'RETSIGTYPE': 'void',
 'RUNSHARED': '',
 'SCRIPTDIR': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib',
 'SETPGRP_HAVE_ARG': 0,
 'SHELL': '/bin/sh',
 'SHLIBS': '-ldl  -lpthread',
 'SHLIB_SUFFIX': '.so',
 'SIGNED_RIGHT_SHIFT_ZERO_FILLS': 0,
 'SITEPATH': '',
 'SIZEOF_DOUBLE': 8,
 'SIZEOF_FLOAT': 4,
 'SIZEOF_FPOS_T': 8,
 'SIZEOF_INT': 4,
 'SIZEOF_LONG': 8,
 'SIZEOF_LONG_DOUBLE': 8,
 'SIZEOF_LONG_LONG': 8,
 'SIZEOF_OFF_T': 8,
 'SIZEOF_PID_T': 4,
 'SIZEOF_PTHREAD_KEY_T': 8,
 'SIZEOF_PTHREAD_T': 8,
 'SIZEOF_SHORT': 2,
 'SIZEOF_SIZE_T': 8,
 'SIZEOF_TIME_T': 8,
 'SIZEOF_UINTPTR_T': 8,
 'SIZEOF_VOID_P': 8,
 'SIZEOF_WCHAR_T': 4,
 'SIZEOF__BOOL': 1,
 'SOABI': 'cpython-311-darwin',
 'SRCDIRS': 'Modules   Modules/_blake2   Modules/_ctypes   Modules/_decimal   '
            'Modules/_decimal/libmpdec   Modules/_io   '
            'Modules/_multiprocessing   Modules/_sha3   Modules/_sqlite   '
            'Modules/_sre   Modules/_xxtestfuzz   Modules/cjkcodecs   '
            'Modules/expat   Objects   Parser   Programs   Python   '
            'Python/frozen_modules   Python/deepfreeze',
 'SRC_GDB_HOOKS': './Tools/gdb/libpython.py',
 'STATIC_LIBPYTHON': 1,
 'STDC_HEADERS': 1,
 'STRICT_SYSV_CURSES': "/* Don't use ncurses extensions */",
 'STRIPFLAG': '-s',
 'SUBDIRS': '',
 'SUBDIRSTOO': 'Include Lib Misc',
 'SYSLIBS': '-lm',
 'SYS_SELECT_WITH_SYS_TIME': 1,
 'TESTOPTS': '',
 'TESTPATH': '',
 'TESTPYTHON': '_PYTHON_PROJECT_BASE=/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6 '
               '_PYTHON_HOST_PLATFORM=$(_PYTHON_HOST_PLATFORM) '
               'PYTHONPATH=$(shell test -f pybuilddir.txt && echo '
               '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6/`cat '
               'pybuilddir.txt`:)./Lib '
               '_PYTHON_SYSCONFIGDATA_NAME=_sysconfigdata__ios_darwin '
               '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/hostpython3/bin/python3',
 'TESTPYTHONOPTS': '',
 'TESTRUNNER': '_PYTHON_PROJECT_BASE=/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6 '
               '_PYTHON_HOST_PLATFORM=$(_PYTHON_HOST_PLATFORM) '
               'PYTHONPATH=$(shell test -f pybuilddir.txt && echo '
               '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6/`cat '
               'pybuilddir.txt`:)./Lib '
               '_PYTHON_SYSCONFIGDATA_NAME=_sysconfigdata__ios_darwin '
               '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/hostpython3/bin/python3 '
               './Tools/scripts/run_tests.py',
 'TESTSUBDIRS': 'ctypes/test \\',
 'TESTTIMEOUT': 1200,
 'TEST_MODULES': 'yes',
 'THREAD_STACK_SIZE': 0,
 'TIMEMODULE_LIB': 0,
 'TIME_WITH_SYS_TIME': 1,
 'TM_IN_SYS_TIME': 0,
 'TZPATH': '/usr/share/zoneinfo:/usr/lib/zoneinfo:/usr/share/lib/zoneinfo:/etc/zoneinfo',
 'UNICODE_DEPS': '\\',
 'UNIVERSALSDK': '',
 'UPDATE_FILE': './Tools/scripts/update_file.py',
 'USE_COMPUTED_GOTOS': 0,
 'VERSION': '3.11',
 'WASM_ASSETS_DIR': './private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3',
 'WASM_STDLIB': './private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/lib/python3.11/os.py',
 'WHEEL_PKG_DIR': '',
 'WINDOW_HAS_FLAGS': 0,
 'WITH_DECIMAL_CONTEXTVAR': 1,
 'WITH_DOC_STRINGS': 1,
 'WITH_DTRACE': 0,
 'WITH_DYLD': 0,
 'WITH_EDITLINE': 0,
 'WITH_FREELISTS': 1,
 'WITH_LIBINTL': 0,
 'WITH_NEXT_FRAMEWORK': 0,
 'WITH_PYMALLOC': 1,
 'WITH_VALGRIND': 0,
 'X87_DOUBLE_ROUNDING': 0,
 'XMLLIBSUBDIRS': 'xml xml/dom xml/etree xml/parsers xml/sax',
 'abs_builddir': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6',
 'abs_srcdir': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/build/python3/iphoneos-arm64/Python-3.11.6',
 'datarootdir': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3/share',
 'exec_prefix': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3',
 'prefix': '/private/tmp/claude-501/-Users-leon-Repositories-YoutubeDL/0e47008f-ac18-43f3-849d-6e8814390c3e/scratchpad/kivy-ios-upstream/dist/root/python3',
 'srcdir': '.'}
